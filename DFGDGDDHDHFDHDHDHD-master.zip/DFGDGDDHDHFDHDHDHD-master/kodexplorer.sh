chmod -R 777 /usr/share/nginx/kodexplorer/data/User/admin/home/
